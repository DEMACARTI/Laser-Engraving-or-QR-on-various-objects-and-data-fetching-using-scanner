import React, { useState, useEffect } from 'react';
import './EngravePage.css';

const API_BASE = 'http://localhost:5000'; // Change if backend runs elsewhere

export default function EngravePage() {
  const [items, setItems] = useState([]);
  const [status, setStatus] = useState('');
  const [jobRunning, setJobRunning] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [delay, setDelay] = useState(0); // delay in seconds
  const [count, setCount] = useState(1); // number of QRs to engrave

  // Fetch items to engrave
  const fetchItems = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`${API_BASE}/engrave/items`);
      const data = await res.json();
      setItems(data.items || []);
    } catch (e) {
      setError('Failed to fetch items');
    }
    setLoading(false);
  };

  // Fetch engraving job status
  const fetchStatus = async () => {
    try {
      const res = await fetch(`${API_BASE}/engrave/status`);
      const data = await res.json();
      setStatus(data.status || '');
      setJobRunning(data.running || false);
    } catch (e) {
      setStatus('Error fetching status');
    }
  };

  useEffect(() => {
    fetchItems();
    fetchStatus();
    const interval = setInterval(() => {
      fetchStatus();
      fetchItems();
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  // Job controls
  const startJob = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`${API_BASE}/engrave/start`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ delay, count }), // send delay and count to backend if supported
      });
      if (!res.ok) throw new Error();
      fetchStatus();
    } catch (e) {
      setError('Failed to start job');
    }
    setLoading(false);
  };
  const pauseJob = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`${API_BASE}/engrave/pause`, { method: 'POST' });
      if (!res.ok) throw new Error();
      fetchStatus();
    } catch (e) {
      setError('Failed to pause job');
    }
    setLoading(false);
  };
  const resumeJob = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`${API_BASE}/engrave/resume`, { method: 'POST' });
      if (!res.ok) throw new Error();
      fetchStatus();
    } catch (e) {
      setError('Failed to resume job');
    }
    setLoading(false);
  };
  const stopJob = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch(`${API_BASE}/engrave/stop`, { method: 'POST' });
      if (!res.ok) throw new Error();
      fetchStatus();
    } catch (e) {
      setError('Failed to stop job');
    }
    setLoading(false);
  };

  return (
    <div className="engrave-container">
      <h1 className="engrave-title">Engraving Control Panel</h1>
      <div className="engrave-status">Status: <b>{status}</b></div>
      {error && <div className="engrave-error">{error}</div>}
      <div className="engrave-controls">
        <label>
          Number of QRs to engrave:
          <input
            type="number"
            min="1"
            max={items.length}
            value={count}
            onChange={e => setCount(Number(e.target.value))}
          />
        </label>
        <label>
          Delay after each QR (seconds):
          <input
            type="number"
            min="0"
            max="60"
            value={delay}
            onChange={e => setDelay(Number(e.target.value))}
          />
        </label>
      </div>
      <div className="engrave-buttons">
        <button onClick={startJob} disabled={jobRunning || loading}>Start</button>
        <button onClick={pauseJob} disabled={!jobRunning || loading}>Pause</button>
        <button onClick={resumeJob} disabled={jobRunning || loading}>Resume</button>
        <button onClick={stopJob} disabled={!jobRunning || loading}>Stop</button>
      </div>
      <h2 style={{marginTop: 24, marginBottom: 8}}>Items to Engrave</h2>
      {loading ? <div>Loading...</div> : (
        <table className="engrave-table">
          <thead>
            <tr>
              <th>UID</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {items.map(item => (
              <tr key={item.uid}>
                <td>{item.uid}</td>
                <td>{item.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
