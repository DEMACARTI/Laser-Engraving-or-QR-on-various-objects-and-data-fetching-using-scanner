import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./App.css";
import EngravePage from "./pages/EngravePage";
import { useState } from "react";

function MainRouter() {
  const [showEngrave, setShowEngrave] = useState(false);

  // This is a placeholder for actual navigation logic.
  // In real app, use React Router or similar.
  if (showEngrave) return <EngravePage />;
  return <App onDone={() => setShowEngrave(true)} />;
}

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <MainRouter />
  </React.StrictMode>
);
